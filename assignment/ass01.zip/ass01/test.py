import numpy as np
import matplotlib.pyplot as plt

# 参数设置
theta_star = 3  # 真实参数值
num_iterations = 1000  # 迭代次数
theta = 0  # 初始估计值

# 存储每次迭代的结果
theta_history = [theta]

# 迭代过程
for n in range(1, num_iterations + 1):
    # 计算带噪声的梯度观测
    epsilon = np.random.normal(0, 1)  # 随机噪声
    Y_n = 2 * (theta - theta_star) + epsilon
    
    # 更新估计值
    a_n = 1 / n  # 步长
    theta = theta - a_n * Y_n
    
    # 记录当前估计值
    theta_history.append(theta)

# 输出最终估计值
print("最终估计值:", theta)

# 可视化结果
plt.plot(theta_history)
plt.axhline(y=theta_star, color='r', linestyle='--', label='真实值')
plt.xlabel('迭代次数')
plt.ylabel('估计值')
plt.title('Robbins-Monro 方法估计过程')
plt.legend()
plt.show()