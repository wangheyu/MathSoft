#ifndef SCENE_C3T3_ITEM_CONFIG_H
#define SCENE_C3T3_ITEM_CONFIG_H

#ifdef scene_c3t3_item_EXPORTS
#  define mesh_3_demo_scene_c3t3_item_EXPORTS 1
#endif

#ifdef mesh_3_demo_scene_c3t3_item_EXPORTS
#  define SCENE_C3T3_ITEM_EXPORT Q_DECL_EXPORT
#else
#  define SCENE_C3T3_ITEM_EXPORT Q_DECL_IMPORT
#endif

#endif // SCENE_C3T3_ITEM_CONFIG_H
