#ifndef IMAGE_TYPE_H
#define IMAGE_TYPE_H

#include <CGAL/Image_3.h>

typedef CGAL::Image_3 Image;

#endif // IMAGE_TYPE_H
